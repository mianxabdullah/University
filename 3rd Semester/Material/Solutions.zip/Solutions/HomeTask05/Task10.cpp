#include<iostream>
using namespace std;

void towerOfHanoi(int n, char source, char destination, char helper)
{
    if(n == 1)
     cout << "Move disk 1 from " << source << " to " << destination << endl;

    else
    {
        towerOfHanoi(n-1 , source , helper , destination);
        cout << "Move disk "<< n <<" from " << source << " to " << destination << endl;
        towerOfHanoi(n-1 , helper , destination , source);
    }
}

int main()
{
    towerOfHanoi(2, 'A' , 'C' , 'B');
}